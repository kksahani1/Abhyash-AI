package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.ui.screens.MainAssessmentScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.AbhyasAITheme
import com.example.ui.theme.AbhyasNavyDark

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AbhyasAITheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = AbhyasNavyDark
                ) {
                    AbhyasApp()
                }
            }
        }
    }
}

@Composable
fun AbhyasApp() {
    var isSplashActive by remember { mutableStateOf(true) }

    Crossfade(
        targetState = isSplashActive,
        animationSpec = tween(durationMillis = 600),
        label = "AppScreenTransition"
    ) { showSplash ->
        if (showSplash) {
            SplashScreen(
                onSplashFinished = { isSplashActive = false }
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .background(AbhyasNavyDark)
            ) {
                MainAssessmentScreen()
            }
        }
    }
}
