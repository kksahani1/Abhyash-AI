package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AbhyasCyan
import com.example.ui.theme.AbhyasCyanDark
import com.example.ui.theme.AbhyasCyanLight
import com.example.ui.theme.AbhyasGreenSuccess
import com.example.ui.theme.AbhyasIndigo
import com.example.ui.theme.AbhyasPurple
import kotlin.math.cos
import kotlin.math.sin

/**
 * Custom vector canvas component recreating the exact AbhyasAI Logo:
 * - Stylized futuristic letter 'A' with cyan-to-indigo gradient
 * - Dynamic upward growth arrow swoosh
 * - AI neural network orbital node circle with 3 data nodes
 * - Glowing 4-pointed sparkle star at the apex
 * - Tablet/Pad assessment device element
 */
@Composable
fun AbhyasLogo(
    modifier: Modifier = Modifier,
    size: Dp = 120.dp,
    animated: Boolean = true
) {
    val infiniteTransition = rememberInfiniteTransition(label = "AbhyasLogoAnim")

    val pulseGlow by if (animated) {
        infiniteTransition.animateFloat(
            initialValue = 0.7f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(1800, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulseGlow"
        )
    } else {
        androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(1f) }
    }

    val rotationNode by if (animated) {
        infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(10000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "rotationNode"
        )
    } else {
        androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            val scale = w / 108f

            // 1. Ambient Background Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        AbhyasCyan.copy(alpha = 0.25f * pulseGlow),
                        AbhyasIndigo.copy(alpha = 0.15f * pulseGlow),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.5f, h * 0.5f),
                    radius = w * 0.55f
                )
            )

            // 2. Glowing Star atop Apex (x: 54, y: 22)
            drawGlowingStar(
                center = Offset(54f * scale, 22f * scale),
                radius = 6.5f * scale * pulseGlow,
                color = AbhyasCyan
            )

            // 3. AI Neural Orbit arc
            val orbitCenter = Offset(58f * scale, 56f * scale)
            val orbitRadius = 17f * scale
            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(AbhyasCyan, AbhyasTealCompat(), AbhyasIndigo, AbhyasCyan),
                    center = orbitCenter
                ),
                startAngle = -45f,
                sweepAngle = 260f,
                useCenter = false,
                style = Stroke(width = 2.4f * scale, cap = StrokeCap.Round),
                topLeft = Offset(orbitCenter.x - orbitRadius, orbitCenter.y - orbitRadius),
                size = Size(orbitRadius * 2, orbitRadius * 2)
            )

            // Orbit Connected Nodes
            val nodeAngle1 = Math.toRadians((-40.0 + rotationNode * 0.2))
            val node1X = orbitCenter.x + (orbitRadius * cos(nodeAngle1)).toFloat()
            val node1Y = orbitCenter.y + (orbitRadius * sin(nodeAngle1)).toFloat()
            drawCircle(
                color = AbhyasCyan,
                radius = 3.2f * scale,
                center = Offset(node1X, node1Y)
            )

            val nodeAngle2 = Math.toRadians((45.0 + rotationNode * 0.2))
            val node2X = orbitCenter.x + (orbitRadius * cos(nodeAngle2)).toFloat()
            val node2Y = orbitCenter.y + (orbitRadius * sin(nodeAngle2)).toFloat()
            drawCircle(
                color = AbhyasGreenSuccess,
                radius = 3.4f * scale,
                center = Offset(node2X, node2Y)
            )

            val nodeAngle3 = Math.toRadians((140.0 + rotationNode * 0.2))
            val node3X = orbitCenter.x + (orbitRadius * cos(nodeAngle3)).toFloat()
            val node3Y = orbitCenter.y + (orbitRadius * sin(nodeAngle3)).toFloat()
            drawCircle(
                color = AbhyasCyanLight,
                radius = 3.0f * scale,
                center = Offset(node3X, node3Y)
            )

            // 4. Stylized Letter 'A' Left Leg
            val leftLegPath = Path().apply {
                moveTo(54f * scale, 34f * scale)
                lineTo(48f * scale, 34f * scale)
                lineTo(32f * scale, 75f * scale)
                lineTo(40f * scale, 75f * scale)
                lineTo(44.5f * scale, 63f * scale)
                lineTo(52.5f * scale, 63f * scale)
                lineTo(53.2f * scale, 56f * scale)
                lineTo(47.5f * scale, 56f * scale)
                lineTo(51.8f * scale, 43.5f * scale)
                lineTo(54f * scale, 37f * scale)
                close()
            }
            drawPath(
                path = leftLegPath,
                brush = Brush.linearGradient(
                    colors = listOf(AbhyasCyanDark, AbhyasCyan, AbhyasCyanLight),
                    start = Offset(32f * scale, 75f * scale),
                    end = Offset(54f * scale, 34f * scale)
                )
            )

            // 5. Stylized Letter 'A' Right Leg
            val rightLegPath = Path().apply {
                moveTo(54f * scale, 34f * scale)
                lineTo(58f * scale, 34f * scale)
                lineTo(74f * scale, 75f * scale)
                lineTo(66.5f * scale, 75f * scale)
                lineTo(62f * scale, 63f * scale)
                lineTo(54f * scale, 63f * scale)
                lineTo(53.2f * scale, 56f * scale)
                lineTo(59.5f * scale, 56f * scale)
                lineTo(56.8f * scale, 43.5f * scale)
                lineTo(54f * scale, 37f * scale)
                close()
            }
            drawPath(
                path = rightLegPath,
                brush = Brush.linearGradient(
                    colors = listOf(AbhyasCyanLight, AbhyasIndigo, AbhyasPurple),
                    start = Offset(54f * scale, 34f * scale),
                    end = Offset(74f * scale, 75f * scale)
                )
            )

            // 6. Assessment Tablet / Pad Icon base (left-lower corner)
            val padPath = Path().apply {
                moveTo(32f * scale, 59f * scale)
                lineTo(45f * scale, 59f * scale)
                lineTo(43f * scale, 75f * scale)
                lineTo(30f * scale, 75f * scale)
                close()
            }
            drawPath(
                path = padPath,
                brush = Brush.linearGradient(
                    colors = listOf(AbhyasCyan, AbhyasCyanDark),
                    start = Offset(30f * scale, 59f * scale),
                    end = Offset(45f * scale, 75f * scale)
                ),
                style = Fill
            )
            drawPath(
                path = padPath,
                color = AbhyasCyanLight,
                style = Stroke(width = 2f * scale, join = StrokeJoin.Round)
            )

            // 7. Dynamic Upward Growth Arrow Swoosh
            val arrowPath = Path().apply {
                moveTo(42f * scale, 70f * scale)
                cubicTo(
                    49f * scale, 70f * scale,
                    59f * scale, 66f * scale,
                    67f * scale, 53f * scale
                )
                lineTo(62f * scale, 51f * scale)
                lineTo(74f * scale, 43f * scale)
                lineTo(74f * scale, 56f * scale)
                lineTo(70f * scale, 54f * scale)
                cubicTo(
                    63f * scale, 68f * scale,
                    51f * scale, 73f * scale,
                    42f * scale, 72f * scale
                )
                close()
            }
            drawPath(
                path = arrowPath,
                brush = Brush.linearGradient(
                    colors = listOf(AbhyasCyan, AbhyasCyanLight, Color.White),
                    start = Offset(42f * scale, 72f * scale),
                    end = Offset(74f * scale, 43f * scale)
                )
            )
        }
    }
}

private fun DrawScope.drawGlowingStar(center: Offset, radius: Float, color: Color) {
    val starPath = Path().apply {
        moveTo(center.x, center.y - radius)
        lineTo(center.x + radius * 0.3f, center.y - radius * 0.3f)
        lineTo(center.x + radius, center.y)
        lineTo(center.x + radius * 0.3f, center.y + radius * 0.3f)
        lineTo(center.x, center.y + radius)
        lineTo(center.x - radius * 0.3f, center.y + radius * 0.3f)
        lineTo(center.x - radius, center.y)
        lineTo(center.x - radius * 0.3f, center.y - radius * 0.3f)
        close()
    }
    drawPath(path = starPath, color = color)
    drawCircle(
        color = color.copy(alpha = 0.5f),
        radius = radius * 0.8f,
        center = center
    )
}

private fun AbhyasTealCompat() = Color(0xFF14B8A6)
