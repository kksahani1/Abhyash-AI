package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AbhyasCyan,
    onPrimary = AbhyasNavyDark,
    primaryContainer = AbhyasCyanDark,
    onPrimaryContainer = Color.White,
    secondary = AbhyasIndigo,
    onSecondary = Color.White,
    secondaryContainer = AbhyasNavySurface,
    onSecondaryContainer = AbhyasCyanLight,
    tertiary = AbhyasTeal,
    onTertiary = Color.White,
    background = AbhyasNavyDark,
    onBackground = AbhyasTextPrimary,
    surface = AbhyasNavyCard,
    onSurface = AbhyasTextPrimary,
    surfaceVariant = AbhyasNavySurface,
    onSurfaceVariant = AbhyasTextSecondary,
    outline = AbhyasNavyBorder,
    error = AbhyasRedError,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = AbhyasCyanDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F7FA),
    onPrimaryContainer = AbhyasNavyDark,
    secondary = AbhyasIndigo,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEEF2FF),
    onSecondaryContainer = AbhyasIndigo,
    tertiary = AbhyasTeal,
    onTertiary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = AbhyasRedError,
    onError = Color.White
)

@Composable
fun AbhyasAITheme(
    darkTheme: Boolean = true, // Default to sleek AI dark mode
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
