package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.components.AbhyasLogo
import com.example.ui.theme.AbhyasCyan
import com.example.ui.theme.AbhyasCyanLight
import com.example.ui.theme.AbhyasGreenSuccess
import com.example.ui.theme.AbhyasIndigo
import com.example.ui.theme.AbhyasNavyCard
import com.example.ui.theme.AbhyasNavyDark
import com.example.ui.theme.AbhyasNavySurface
import com.example.ui.theme.AbhyasPurple
import com.example.ui.theme.AbhyasTextMuted
import com.example.ui.theme.AbhyasTextPrimary
import com.example.ui.theme.AbhyasTextSecondary

@Composable
fun AboutAppDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = AbhyasNavyCard),
            border = BorderStroke(1.dp, AbhyasCyan.copy(alpha = 0.3f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .testTag("about_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "About Portal",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = AbhyasCyan
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = AbhyasTextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Branded Logo
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(AbhyasNavySurface)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AbhyasLogo(size = 64.dp, animated = false)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "AbhyasAI",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )

                Text(
                    text = "AI Exam Preparation & Online Assessment System",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = AbhyasCyanLight,
                    textAlign = TextAlign.Center,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Feature grid
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    InfoTile(
                        icon = Icons.Default.School,
                        title = "Smart Exam Prep",
                        desc = "AI-curated assessments and practice tests tailored for mastery.",
                        iconColor = AbhyasCyan
                    )
                    InfoTile(
                        icon = Icons.Default.Assessment,
                        title = "Real-Time Evaluation",
                        desc = "Instant scoring, detailed solution analysis, and progress benchmarks.",
                        iconColor = AbhyasPurple
                    )
                    InfoTile(
                        icon = Icons.Default.Shield,
                        title = "Secure CBT Portal",
                        desc = "Safe assessment environment with anti-cheat and high reliability.",
                        iconColor = AbhyasGreenSuccess
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AbhyasNavySurface,
                        contentColor = AbhyasCyan
                    ),
                    border = BorderStroke(1.dp, AbhyasCyan.copy(alpha = 0.4f))
                ) {
                    Text("Continue to Assessment", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun InfoTile(
    icon: ImageVector,
    title: String,
    desc: String,
    iconColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(AbhyasNavyDark.copy(alpha = 0.6f))
            .padding(10.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(iconColor.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(18.dp)
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = AbhyasTextPrimary
            )
            Text(
                text = desc,
                fontSize = 11.sp,
                color = AbhyasTextSecondary,
                lineHeight = 14.sp
            )
        }
    }
}
