package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AbhyasLogo
import com.example.ui.theme.AbhyasCyan
import com.example.ui.theme.AbhyasCyanDark
import com.example.ui.theme.AbhyasCyanLight
import com.example.ui.theme.AbhyasGreenSuccess
import com.example.ui.theme.AbhyasIndigo
import com.example.ui.theme.AbhyasNavyCard
import com.example.ui.theme.AbhyasNavyDark
import com.example.ui.theme.AbhyasNavySurface
import com.example.ui.theme.AbhyasPurple
import com.example.ui.theme.AbhyasTextMuted
import com.example.ui.theme.AbhyasTextPrimary
import com.example.ui.theme.AbhyasTextSecondary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onSplashFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    var startAnimation by remember { mutableStateOf(false) }

    val logoScale by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0.7f,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "logoScale"
    )

    val contentAlpha by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(durationMillis = 800, delayMillis = 250),
        label = "contentAlpha"
    )

    LaunchedEffect(Unit) {
        startAnimation = true
        // Keep splash elegant and quick for user responsiveness (1.8s)
        delay(1800)
        onSplashFinished()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        AbhyasNavyDark,
                        Color(0xFF0B132B),
                        Color(0xFF0A0F1D)
                    )
                )
            )
            .testTag("splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        // Subtle ambient neon blur rings in the background
        Box(
            modifier = Modifier
                .size(280.dp)
                .alpha(0.18f)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(AbhyasCyan, AbhyasIndigo, Color.Transparent)
                    ),
                    shape = CircleShape
                )
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Main Logo in perfect proportional size
            Box(
                modifier = Modifier
                    .size(150.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                AbhyasNavySurface.copy(alpha = 0.85f),
                                AbhyasNavyCard.copy(alpha = 0.95f)
                            ),
                            start = Offset(0f, 0f),
                            end = Offset(150f, 150f)
                        )
                    )
                    .padding(14.dp),
                contentAlignment = Alignment.Center
            ) {
                AbhyasLogo(
                    size = 120.dp,
                    animated = true,
                    modifier = Modifier.testTag("splash_logo")
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // App Main Title
            Text(
                text = "AbhyasAI",
                fontSize = 38.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.2.sp,
                style = androidx.compose.ui.text.TextStyle(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.White,
                            AbhyasCyanLight,
                            AbhyasCyan
                        )
                    )
                ),
                modifier = Modifier
                    .alpha(contentAlpha)
                    .testTag("splash_title")
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Tagline / Subtitle
            Text(
                text = "AI Exam Preparation & Online Assessment System",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = AbhyasCyanLight,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp,
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .alpha(contentAlpha)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Feature Badges
            Row(
                modifier = Modifier
                    .alpha(contentAlpha)
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FeatureBadge(
                    icon = Icons.Default.Psychology,
                    label = "AI Engine",
                    accentColor = AbhyasCyan
                )
                FeatureBadge(
                    icon = Icons.Default.AutoAwesome,
                    label = "Live Tests",
                    accentColor = AbhyasPurple
                )
                FeatureBadge(
                    icon = Icons.Default.Speed,
                    label = "Fast & Smooth",
                    accentColor = AbhyasGreenSuccess
                )
            }

            Spacer(modifier = Modifier.height(48.dp))

            // Progress bar and loading text
            Column(
                modifier = Modifier
                    .alpha(contentAlpha)
                    .width(200.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = AbhyasCyan,
                    trackColor = AbhyasNavySurface
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Initializing Assessment Portal…",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    color = AbhyasTextMuted,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Footer version tag
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp)
                .alpha(contentAlpha)
        ) {
            Text(
                text = "Secure CBT Portal • Version 1.0",
                fontSize = 11.sp,
                color = AbhyasTextMuted
            )
        }
    }
}

@Composable
private fun FeatureBadge(
    icon: ImageVector,
    label: String,
    accentColor: Color
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = AbhyasNavySurface.copy(alpha = 0.7f)
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = AbhyasTextPrimary
            )
        }
    }
}
