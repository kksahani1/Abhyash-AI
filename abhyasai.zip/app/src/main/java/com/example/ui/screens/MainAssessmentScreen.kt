package com.example.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CloseFullscreen
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.components.AbhyasLogo
import com.example.ui.dialogs.AboutAppDialog
import com.example.ui.theme.AbhyasCyan
import com.example.ui.theme.AbhyasCyanDark
import com.example.ui.theme.AbhyasCyanLight
import com.example.ui.theme.AbhyasGreenSuccess
import com.example.ui.theme.AbhyasIndigo
import com.example.ui.theme.AbhyasNavyBorder
import com.example.ui.theme.AbhyasNavyCard
import com.example.ui.theme.AbhyasNavyDark
import com.example.ui.theme.AbhyasNavySurface
import com.example.ui.theme.AbhyasPurple
import com.example.ui.theme.AbhyasTextMuted
import com.example.ui.theme.AbhyasTextPrimary
import com.example.ui.theme.AbhyasTextSecondary

const val ABHYAS_ASSESSMENT_URL =
    "https://script.google.com/macros/s/AKfycbyNwq9DMgI2W6qqBsN_1h8v2LePYFWdgKti_SLL1WfCpMlzQp8mSffsBPyLXb_aL9bi/exec"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MainAssessmentScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var webProgress by remember { mutableFloatStateOf(0f) }
    var isLoading by remember { mutableStateOf(true) }
    var pageTitle by remember { mutableStateOf("AbhyasAI Exam Portal") }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var hasError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    var isFullscreenExamMode by remember { mutableStateOf(false) }
    var showExitDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    // File Chooser for Web forms (uploading exam answers, photos, docs)
    var filePathCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

    val fileChooserLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (filePathCallback != null) {
            val results: Array<Uri>? = if (result.resultCode == Activity.RESULT_OK) {
                val data = result.data
                if (data?.data != null) {
                    arrayOf(data.data!!)
                } else if (data?.clipData != null) {
                    val count = data.clipData!!.itemCount
                    Array(count) { i -> data.clipData!!.getItemAt(i).uri }
                } else {
                    null
                }
            } else {
                null
            }
            filePathCallback?.onReceiveValue(results)
            filePathCallback = null
        }
    }

    // Permission launcher for Camera if needed by WebRTC
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            Toast.makeText(context, "Camera permission enabled for assessment", Toast.LENGTH_SHORT).show()
        }
    }

    // Smart Back Handler
    BackHandler {
        if (isFullscreenExamMode) {
            isFullscreenExamMode = false
        } else if (webViewInstance?.canGoBack() == true) {
            webViewInstance?.goBack()
        } else {
            showExitDialog = true
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AbhyasNavyDark)
            .testTag("main_assessment_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // Top App Bar (Hidden in Fullscreen Exam Mode for distraction-free testing)
            if (!isFullscreenExamMode) {
                AbhyasTopBar(
                    title = pageTitle,
                    isLoading = isLoading,
                    canGoBack = canGoBack,
                    canGoForward = canGoForward,
                    onBackClick = { webViewInstance?.goBack() },
                    onForwardClick = { webViewInstance?.goForward() },
                    onRefreshClick = {
                        hasError = false
                        webViewInstance?.reload()
                    },
                    onHomeClick = {
                        hasError = false
                        webViewInstance?.loadUrl(ABHYAS_ASSESSMENT_URL)
                    },
                    onShareClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "AbhyasAI — AI Exam Preparation & Online Assessment System")
                            putExtra(Intent.EXTRA_TEXT, "Take tests and assessments on AbhyasAI: $ABHYAS_ASSESSMENT_URL")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share AbhyasAI Portal"))
                    },
                    onToggleFullscreen = { isFullscreenExamMode = true },
                    onInfoClick = { showAboutDialog = true }
                )

                // Loading Progress Indicator
                if (isLoading && webProgress < 1f) {
                    LinearProgressIndicator(
                        progress = { webProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(2.5.dp),
                        color = AbhyasCyan,
                        trackColor = AbhyasNavyDark
                    )
                }
            }

            // Content Area: Web Assessment View or Error Fallback
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )

                            setBackgroundColor(0xFF0F172A.toInt())

                            // Advanced Web Settings for Google Apps Script & Assessments
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                databaseEnabled = true
                                allowFileAccess = true
                                allowContentAccess = true
                                loadWithOverviewMode = true
                                useWideViewPort = true
                                setSupportZoom(true)
                                builtInZoomControls = true
                                displayZoomControls = false
                                cacheMode = WebSettings.LOAD_DEFAULT
                                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                mediaPlaybackRequiresUserGesture = false
                                javaScriptCanOpenWindowsAutomatically = true

                                // Modern Mobile User Agent
                                userAgentString = userAgentString.replace("; wv", "")
                            }

                            val cookieManager = CookieManager.getInstance()
                            cookieManager.setAcceptCookie(true)
                            cookieManager.setAcceptThirdPartyCookies(this, true)

                            // WebChromeClient for File Picker, Camera Permissions, & Progress
                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    webProgress = newProgress / 100f
                                    isLoading = newProgress < 100
                                }

                                override fun onReceivedTitle(view: WebView?, title: String?) {
                                    if (!title.isNullOrBlank() && !title.contains("exec", ignoreCase = true)) {
                                        pageTitle = title
                                    }
                                }

                                override fun onShowFileChooser(
                                    view: WebView?,
                                    filePathCallbackParam: ValueCallback<Array<Uri>>?,
                                    fileChooserParams: FileChooserParams?
                                ): Boolean {
                                    filePathCallback?.onReceiveValue(null)
                                    filePathCallback = filePathCallbackParam

                                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                                        type = "*/*"
                                        addCategory(Intent.CATEGORY_OPENABLE)
                                    }

                                    try {
                                        fileChooserLauncher.launch(intent)
                                    } catch (e: Exception) {
                                        filePathCallback = null
                                        return false
                                    }
                                    return true
                                }

                                override fun onPermissionRequest(request: PermissionRequest?) {
                                    request?.let {
                                        val requestedResources = it.resources
                                        var cameraRequested = false
                                        for (res in requestedResources) {
                                            if (res == PermissionRequest.RESOURCE_VIDEO_CAPTURE) {
                                                cameraRequested = true
                                            }
                                        }

                                        if (cameraRequested) {
                                            val hasCam = ContextCompat.checkSelfPermission(
                                                ctx,
                                                android.Manifest.permission.CAMERA
                                            ) == PackageManager.PERMISSION_GRANTED

                                            if (hasCam) {
                                                it.grant(it.resources)
                                            } else {
                                                cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
                                                it.grant(it.resources)
                                            }
                                        } else {
                                            it.grant(it.resources)
                                        }
                                    }
                                }
                            }

                            // WebViewClient with redirect handling & error recovery
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    val url = request?.url?.toString() ?: return false

                                    // Keep Google Apps Script, Google accounts, Forms, Docs within WebView
                                    if (url.startsWith("http://") || url.startsWith("https://")) {
                                        return false
                                    }

                                    // External schemes (tel:, mailto:, market:, whatsapp:)
                                    return try {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                        ctx.startActivity(intent)
                                        true
                                    } catch (e: Exception) {
                                        true
                                    }
                                }

                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    isLoading = true
                                    hasError = false
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    isLoading = false
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                }

                                override fun onReceivedError(
                                    view: WebView?,
                                    request: WebResourceRequest?,
                                    error: WebResourceError?
                                ) {
                                    if (request?.isForMainFrame == true) {
                                        // Ignore benign net cancellations
                                        if (error?.errorCode != ERROR_CONNECT && error?.errorCode != ERROR_HOST_LOOKUP && error?.errorCode != ERROR_TIMEOUT) {
                                            return
                                        }
                                        hasError = true
                                        errorMessage = error?.description?.toString() ?: "Network error"
                                    }
                                }
                            }

                            // PDF & Exam Results Downloader
                            setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
                                try {
                                    val request = DownloadManager.Request(Uri.parse(url)).apply {
                                        setMimeType(mimetype)
                                        addRequestHeader("User-Agent", userAgent)
                                        setDescription("Downloading assessment document…")
                                        setTitle("AbhyasAI Document")
                                        setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                        setDestinationInExternalPublicDir(
                                            Environment.DIRECTORY_DOWNLOADS,
                                            "AbhyasAI_${System.currentTimeMillis()}.pdf"
                                        )
                                    }
                                    val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                    dm.enqueue(request)
                                    Toast.makeText(ctx, "Download started… Check Notifications", Toast.LENGTH_LONG).show()
                                } catch (e: Exception) {
                                    Toast.makeText(ctx, "Download error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                }
                            }

                            loadUrl(ABHYAS_ASSESSMENT_URL)
                            webViewInstance = this
                        }
                    },
                    update = { view ->
                        webViewInstance = view
                    },
                    modifier = Modifier.fillMaxSize()
                )

                // If error occurs, show polished Offline Recovery Screen
                if (hasError) {
                    OfflineErrorScreen(
                        errorMessage = errorMessage,
                        onRetry = {
                            hasError = false
                            webViewInstance?.loadUrl(ABHYAS_ASSESSMENT_URL)
                        }
                    )
                }

                // Fullscreen floating exit button when in CBT exam mode
                if (isFullscreenExamMode) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(16.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = AbhyasNavyDark.copy(alpha = 0.85f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AbhyasCyan.copy(alpha = 0.5f)),
                            shadowElevation = 6.dp
                        ) {
                            IconButton(
                                onClick = { isFullscreenExamMode = false },
                                modifier = Modifier.size(42.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloseFullscreen,
                                    contentDescription = "Exit Fullscreen",
                                    tint = AbhyasCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Dialogs
        if (showExitDialog) {
            AlertDialog(
                onDismissRequest = { showExitDialog = false },
                containerColor = AbhyasNavyCard,
                titleContentColor = Color.White,
                textContentColor = AbhyasTextSecondary,
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = AbhyasCyan
                        )
                        Text("Exit AbhyasAI Portal?")
                    }
                },
                text = {
                    Text(
                        "Are you sure you want to close the AbhyasAI assessment portal? If you are in the middle of a test, your ongoing progress may be saved on the server.",
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showExitDialog = false
                            (context as? Activity)?.finish()
                        }
                    ) {
                        Text("Exit App", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showExitDialog = false }) {
                        Text("Stay on Portal", color = AbhyasCyan)
                    }
                }
            )
        }

        if (showAboutDialog) {
            AboutAppDialog(onDismiss = { showAboutDialog = false })
        }
    }
}

@Composable
private fun AbhyasTopBar(
    title: String,
    isLoading: Boolean,
    canGoBack: Boolean,
    canGoForward: Boolean,
    onBackClick: () -> Unit,
    onForwardClick: () -> Unit,
    onRefreshClick: () -> Unit,
    onHomeClick: () -> Unit,
    onShareClick: () -> Unit,
    onToggleFullscreen: () -> Unit,
    onInfoClick: () -> Unit
) {
    Surface(
        color = AbhyasNavyCard,
        tonalElevation = 4.dp,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            Brush.verticalGradient(listOf(Color.Transparent, AbhyasNavyBorder.copy(alpha = 0.5f)))
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left Brand Logo & Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(AbhyasNavySurface)
                            .padding(4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        AbhyasLogo(size = 30.dp, animated = false)
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "AbhyasAI",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )

                            // Status Pill
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(
                                        if (isLoading) AbhyasCyan.copy(alpha = 0.2f)
                                        else AbhyasGreenSuccess.copy(alpha = 0.2f)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isLoading) "Syncing" else "Online",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isLoading) AbhyasCyan else AbhyasGreenSuccess
                                )
                            }
                        }

                        Text(
                            text = "AI Exam Preparation & Assessment",
                            fontSize = 10.sp,
                            color = AbhyasTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Action Controls
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(0.dp)
                ) {
                    IconButton(
                        onClick = onBackClick,
                        enabled = canGoBack,
                        modifier = Modifier.size(36.dp).testTag("topbar_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = if (canGoBack) AbhyasTextPrimary else AbhyasTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onForwardClick,
                        enabled = canGoForward,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Forward",
                            tint = if (canGoForward) AbhyasTextPrimary else AbhyasTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onRefreshClick,
                        modifier = Modifier.size(36.dp).testTag("topbar_refresh")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reload",
                            tint = AbhyasCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onHomeClick,
                        modifier = Modifier.size(36.dp).testTag("topbar_home")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Home",
                            tint = AbhyasTextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onToggleFullscreen,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fullscreen,
                            contentDescription = "Exam Fullscreen",
                            tint = AbhyasPurple,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = onInfoClick,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "About",
                            tint = AbhyasTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
