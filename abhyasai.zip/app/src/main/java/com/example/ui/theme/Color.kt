package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AbhyasAI Brand Palette
val AbhyasNavyDark = Color(0xFF070B14)
val AbhyasNavyCard = Color(0xFF0F172A)
val AbhyasNavySurface = Color(0xFF1E293B)
val AbhyasNavyBorder = Color(0xFF334155)

val AbhyasCyan = Color(0xFF00E5FF)
val AbhyasCyanLight = Color(0xFF38BDF8)
val AbhyasCyanDark = Color(0xFF0284C7)

val AbhyasTeal = Color(0xFF14B8A6)
val AbhyasIndigo = Color(0xFF6366F1)
val AbhyasPurple = Color(0xFF8B5CF6)

val AbhyasTextPrimary = Color(0xFFF8FAFC)
val AbhyasTextSecondary = Color(0xFF94A3B8)
val AbhyasTextMuted = Color(0xFF64748B)

val AbhyasGreenSuccess = Color(0xFF10B981)
val AbhyasRedError = Color(0xFFEF4444)
val AbhyasAmberWarning = Color(0xFFF59E0B)
